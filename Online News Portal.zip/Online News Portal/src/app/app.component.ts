import { Component, OnChanges, SimpleChanges } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'CorporateNewsPortal';
  token:any;
  constructor() {
    
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.token = localStorage.getItem('token')
    console.log(this.token);
  }
}