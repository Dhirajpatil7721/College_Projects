import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegistrationFormComponent } from './components/registration-form/registration-form.component';
import { NewsComponent } from './components/news/news.component';
import { HomeComponent } from './components/home/home.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { AdminDashboardComponent } from './components/dashboards/admin-dashboard/admin-dashboard.component';
import { NewsRequestComponent } from './components/dashboards/adminComponents/news-request/news-request.component';
import { AddCategoryComponent } from './components/dashboards/adminComponents/add-category/add-category.component';
import { RegRequestComponent } from './components/dashboards/adminComponents/reg-request/reg-request.component';
import { RegNotificationComponent } from './components/reg-notification/reg-notification.component';
import { CreateNewsComponent } from './components/dashboards/adminComponents/create-news/create-news.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { DeleteNewsComponent } from './components/dashboards/adminComponents/delete-news/delete-news.component';
import { EmployeeDashboardComponent } from './components/dashboards/employee-dashboard/employee-dashboard.component';
import { PersonalProfileComponent } from './components/dashboards/employeeComponents/personal-profile/personal-profile.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  {
    path: 'admin',
    component: AdminDashboardComponent,
    children: [
      { path: 'addcategory', component: AddCategoryComponent, outlet: 'child' },
      { path: '', component: RegRequestComponent, outlet: 'child' },
      { path: 'regRequest', component: RegRequestComponent, outlet: 'child' },
      { path: 'newsRequest', component: NewsRequestComponent, outlet: 'child' },
      { path: 'createNews', component: CreateNewsComponent, outlet: 'child' },
      { path: 'allnews', component: NewsComponent, outlet: 'child' },
      { path: 'deleteNews', component: DeleteNewsComponent, outlet: 'child' },
    ],
  },
  {
    path: 'employee',
    component: EmployeeDashboardComponent,
    children: [
      { path: '', component: NewsComponent, outlet: 'child' },
      {path: 'personalProfile',component: PersonalProfileComponent,outlet: 'child'},
      { path: 'createNews', component: CreateNewsComponent, outlet: 'child' },
      { path: 'news', component: NewsComponent, outlet: 'child' },
      {path: 'update-profile',component: UpdateProfileComponent,outlet: 'child'},
    ],
  },
  { path: 'login', component: LoginComponent },
  { path: 'registration', component: RegistrationFormComponent },
  { path: 'regnotification', component: RegNotificationComponent },
  { path: 'aboutus', component: AboutusComponent },
  { path: '**', component: PagenotfoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule],
})
export class AppRoutingModule {}
