export interface IRegister {
    firstName: string;
    lastName:string,
    userName: string,
    email: string,
   
    password: string
    
}
