import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { RegistrationFormComponent } from './components/registration-form/registration-form.component';
import { LoginComponent } from './components/login/login.component';
import { NewsComponent } from './components/news/news.component';
import {FormsModule,ReactiveFormsModule,FormGroup,FormControl} from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { HomeComponent } from './components/home/home.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { AdminDashboardComponent } from './components/dashboards/admin-dashboard/admin-dashboard.component';
import { RegRequestComponent } from './components/dashboards/adminComponents/reg-request/reg-request.component';
import { NewsRequestComponent } from './components/dashboards/adminComponents/news-request/news-request.component';
import { AddCategoryComponent } from './components/dashboards/adminComponents/add-category/add-category.component';
import { RegNotificationComponent } from './components/reg-notification/reg-notification.component';
import { CreateNewsComponent } from './components/dashboards/adminComponents/create-news/create-news.component';
import { FilterPipe } from './shared/filter.pipe';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { DeleteNewsComponent } from './components/dashboards/adminComponents/delete-news/delete-news.component';
import { EmployeeDashboardComponent } from './components/dashboards/employee-dashboard/employee-dashboard.component';
import { PersonalProfileComponent } from './components/dashboards/employeeComponents/personal-profile/personal-profile.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    RegistrationFormComponent,
    LoginComponent,
    NewsComponent,
    AboutusComponent,
    HomeComponent,
    PagenotfoundComponent,
    AdminDashboardComponent,
    RegRequestComponent,
    NewsRequestComponent,
    AddCategoryComponent,
    RegNotificationComponent,
    CreateNewsComponent,
    FilterPipe,
    UpdateProfileComponent,
    DeleteNewsComponent,
    EmployeeDashboardComponent,
    PersonalProfileComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ToastrModule.forRoot({ timeOut: 2000 }),
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
