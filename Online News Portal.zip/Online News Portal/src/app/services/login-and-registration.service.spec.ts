import { TestBed } from '@angular/core/testing';

import { LoginAndRegistrationserviceService } from './login-and-registrationservice.service';

describe('LoginAndRegistrationserviceService', () => {
  let service: LoginAndRegistrationserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoginAndRegistrationserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
