import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class EmployeeServiceService {
  url = 'http://localhost:5000/api/';
  constructor(private http: HttpClient) {}

  getHttpOptions = () => {
    let header_object = new HttpHeaders()
      .set('Authorization', 'Bearer ' + localStorage.getItem('token'))
      .set('Content-Type', 'application/json');

    return {
      headers: header_object,
    };
  };

  getAllCategory = () => {
    const httpOptions = this.getHttpOptions();
    return this.http.get(this.url + 'Employee/category', httpOptions);
  };

  CreateNews = (body: any) => {
    const httpOptions = this.getHttpOptions();
    return this.http.post(
      this.url +'Employee/Create_news',
      body,
      httpOptions
    );
  };

  getEmployeeDetailsByUserName(userName: string) {
    const httpOptions = this.getHttpOptions();
  
    return this.http.get(
      this.url +'Employee/getuserdetailsbyname/' + userName,
      httpOptions
    );
  }

  getData() {
    const httpOptions = this.getHttpOptions();
    return this.http.get(this.url + 'Employee/News', httpOptions);
  }

  updateProfilebyUserName(body: any) {
    console.log(body);
    const httpOptions = this.getHttpOptions();
    return this.http.post(
      'http://localhost:5000/updateprofile',
      body,
      httpOptions
    );
  }

  starPerformer() {
    const httpOptions = this.getHttpOptions();
    return this.http.get(
      this.url +'Employee/starperformer',
      httpOptions
    );
  }
}
