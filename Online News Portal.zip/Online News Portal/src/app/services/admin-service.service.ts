import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AdminServicesService {
  url = 'http://localhost:5000/api/';
  constructor(private http: HttpClient) { }

  getHttpOptions = () => {
    let header_object = new HttpHeaders()
      .set('Authorization', 'Bearer ' + localStorage.getItem('token'))
      .set('Content-Type', 'application/json');

    return {
      headers: header_object,
    };
  };

  getAllRegistrationRequests = () => {
    const httpOptions = this.getHttpOptions();

    return this.http.get(this.url + 'Admin/employees', httpOptions);
  };

  approveRegistrationRequest = (em: string) => {

    const httpOptions = this.getHttpOptions();
    return this.http.put(
      this.url + 'Admin/user/toggleStatus/' + em,
      {},
      httpOptions
    );
  };

  getAllNewsRequests = () => {
    const httpOptions = this.getHttpOptions();
    return this.http.get(this.url + 'Admin/news', httpOptions);
  };

  approveNewsRequest = (eid: string) => {
    const httpOptions = this.getHttpOptions();
    return this.http.put(
      this.url + 'Admin/news/toggleStatus/' + eid,
      {},
      httpOptions
    );
  };

  getAllCategory = () => {
    const httpOptions = this.getHttpOptions();
    return this.http.get(this.url + 'Admin/category', httpOptions);
  };

  removeCategory = (id: string) => {
    const httpOptions = this.getHttpOptions();
    return this.http.delete(
      this.url + 'Admin/category/removecategory/' + id,
      httpOptions
    );
  };

  CreateNews = (body: any) => {
    const httpOptions = this.getHttpOptions();
    return this.http.post(
      this.url + 'Admin/Create_news',
      body,
      httpOptions
    );
  };

  getData() {
    const httpOptions = this.getHttpOptions();
    return this.http.get(this.url + 'Admin/AdminNews', httpOptions);
  }

  deleteNewsRequest(id: any) {
    const httpOptions = this.getHttpOptions();
    return this.http.delete(this.url + 'Admin/DeleteNews/' + id, httpOptions);
  }

  addCategory(name: any) {
    const httpOptions = this.getHttpOptions();
    return this.http.post(this.url + 'Admin/Add_Category', name, httpOptions);
  }
}
