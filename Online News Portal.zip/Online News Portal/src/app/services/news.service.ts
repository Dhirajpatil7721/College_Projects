import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class NewsService {
  url = 'http://localhost:5000/api/';
  constructor(private http: HttpClient) {}

  getHttpOptions = () => {
    let header_object = new HttpHeaders()
      .set('Authorization', 'Bearer ' + localStorage.getItem('token'))
      .set('Content-Type', 'application/json');

    return {
      headers: header_object,
    };
  };
  //Fetch News

  //Post News
  postNews(data: any) {
    return this.http.post(this.url, data);
    // console.log("inside post service")
  }

  getUserName() {
    const httpOptions = this.getHttpOptions();
    return this.http.get(this.url + 'Employee/getuserdetails', httpOptions);
  }
}
