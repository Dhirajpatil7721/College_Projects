  
  import { Injectable } from '@angular/core';
  import { HttpClient } from '@angular/common/http';
  
  import { IRegister } from 'src/app/interface/iregister';
  import { ILogin } from '../interface/ilogin';

@Injectable({
  providedIn: 'root'
})
export class LoginAndRegistrationService {
  url = "http://localhost:5000/"
  constructor(private http: HttpClient) {}

  login = (loginModel: ILogin) => {
    return this.http.post(this.url+'login', loginModel);
  };

  register = (regModel: IRegister) => {
    return this.http.post(this.url+'register/employee', regModel);
  };
  
}
