import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegNotificationComponent } from './reg-notification.component';

describe('RegNotificationComponent', () => {
  let component: RegNotificationComponent;
  let fixture: ComponentFixture<RegNotificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegNotificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
