import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-notification',
  templateUrl: './reg-notification.component.html',
  styleUrls: ['./reg-notification.component.scss']
})
export class RegNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
