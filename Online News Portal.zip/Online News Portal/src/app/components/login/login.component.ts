import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { LoginAndRegistrationService } from 'src/app/services/login-and-registration.service';
import { ILogin } from 'src/app/interface/ilogin';
import {JwtHelperService} from '@auth0/angular-jwt'
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  pwdPattern = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}";
  helper = new JwtHelperService();
  loginForm :any
  message:any;
  token:any;
  role:any;
  constructor(private formBuilder: FormBuilder,private router: Router, private loginService: LoginAndRegistrationService, private _toaster : ToastrService ){}

  ngOnInit(): void{
    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
      password: ['', [Validators.required, Validators.pattern(this.pwdPattern)]]
    });
  

  }
 
  onFormSubmit() {
   
    if (this.loginForm.invalid) {
       return;
    }
   
    let loginModel: ILogin ={
      userName: this.loginForm.value["userName"],
      password: this.loginForm.value["password"]
    }
    this.loginService.login(loginModel).subscribe( (res:any) => {
      localStorage.setItem('token', res.token);
      sessionStorage.setItem('userId' , res.userId);
      sessionStorage.setItem('role' , res.role);
      sessionStorage.setItem('userName', res.userName);

      
      this.token = localStorage.getItem('token');
      const decodedToken = this.helper.decodeToken(this.token);
      this.role =sessionStorage.getItem('role');
      console.log(this.role);
      if(this.role == "Admin")
        this.router.navigateByUrl('admin');
      else
        this.router.navigateByUrl('employee');
    },
    (err:any) => {
      
      this._toaster.error("Error while login please check your credential ");
    })
    this.loginForm.reset();
 }
 

  
 get f() {
  return this.loginForm.controls;
}

}
