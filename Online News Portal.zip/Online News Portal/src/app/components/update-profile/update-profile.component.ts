import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';

import { EmployeeServiceService } from 'src/app/services/employee-service.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.scss'],
})
export class UpdateProfileComponent implements OnInit {
  updateProfileForm: any;
  employeeDetails: any;
  userName: any;
  userData: any;
  constructor(
    private fb: FormBuilder,
    private _empService: EmployeeServiceService,
    private _router: Router,
    private _toastr: ToastrService,
    private activatedRoute: ActivatedRoute
  ) {
    this.updateProfileForm = new FormGroup({
      FirstName: new FormControl('', [Validators.required , Validators.pattern('[a-zA-Z][a-zA-Z ]+')]),
      LastName: new FormControl('', Validators.required),
      UserName: new FormControl('', Validators.required),
      Email: new FormControl('', Validators.required),
    });
  }

  ngOnInit(): void {
    this.userName = sessionStorage['userName'];
    this.GetUserData(this.userName);
  }

  GetUserData(userName: any) {
    this._empService
      .getEmployeeDetailsByUserName(userName)
      .subscribe((response: any) => {
        console.log(response);
        this.updateProfileForm = new FormGroup({
          FirstName: new FormControl(response['firstName']),
          LastName: new FormControl(response['lastName']),
          UserName: new FormControl(response['userName']),
          Email: new FormControl(response['email']),
        });
        this.userData = response;
      });
  }

  UpdateUserProfile() {
    this._empService
      .updateProfilebyUserName(this.updateProfileForm.value)
      .subscribe((data: any) => {
        this.userData = this.updateProfileForm;
        this._toastr.success(
          'Profile Has Been Updated successfully',
          'success'
        );
      }),
      (err: HttpErrorResponse) => {
        console.log(err.message);
      };
  }


  get FirstName() { return this.updateProfileForm.get('FirstName'); }
  get LastName() { return this.updateProfileForm.get('LastName'); }
  get Email() { return this.updateProfileForm.get('Email'); }
}
