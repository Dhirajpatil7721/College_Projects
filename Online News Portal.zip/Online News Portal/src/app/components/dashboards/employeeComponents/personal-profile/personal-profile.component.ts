import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';

@Component({
  selector: 'app-personal-profile',
  templateUrl: './personal-profile.component.html',
  styleUrls: ['./personal-profile.component.scss'],
})
export class PersonalProfileComponent implements OnInit {
  userName: any;
  employeeDetails: any;
  constructor(private _empService: EmployeeServiceService) {
    this.employeeDetails = [];
    this.userName = sessionStorage.getItem('userName');
    console.log(this.userName);
  }

  ngOnInit(): void {
    this._empService
      .getEmployeeDetailsByUserName(this.userName)
      .subscribe((response) => {
        this.employeeDetails = response;
        console.log(this.employeeDetails);
      });
  }
}

