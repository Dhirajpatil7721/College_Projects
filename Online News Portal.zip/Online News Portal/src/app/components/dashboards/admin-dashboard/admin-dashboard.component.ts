import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {JwtHelperService} from '@auth0/angular-jwt'


@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  helper = new JwtHelperService();
  userName:any;
  role:any;
  token: any;
  constructor(private router: Router) {
    console.log("here "+localStorage.getItem('token'))
    this.token = localStorage.getItem('token');

    
    if(this.token != null){
      
      const decodedToken = this.helper.decodeToken(this.token);
     console.log(decodedToken);
      this.userName = decodedToken['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name']
      this.role = decodedToken['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
      console.log(this.role);


    }
    
   }
   signOut = ()=>{
     localStorage.removeItem('token');
     sessionStorage.removeItem('userId');
     sessionStorage.removeItem('role');
     this.router.navigateByUrl('home');
   }
  ngOnInit(): void {
  }

}

