import { Component, OnInit, Input } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';
import { AdminServicesService } from 'src/app/services/admin-service.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-news-request',
  templateUrl: './news-request.component.html',
  styleUrls: ['./news-request.component.scss'],
})
export class NewsRequestComponent implements OnInit {
  helper = new JwtHelperService();
  userName: any;
  email: any;
  role: any;
  token: any;
  newsRequests: any;

  message: any;
  employee: any;
  


  constructor(
    private adminService: AdminServicesService,
    private router: Router,
    private toastrService: ToastrService
  ) {
    this.token = localStorage.getItem('token');
    if (this.token != null) {
      const decodedToken = this.helper.decodeToken(this.token);
      this.userName = this.userName =
        decodedToken[
          'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'
        ];
      console.log(this.userName);
      this.email = decodedToken.email;
      this.role = this.role =
        decodedToken[
          'http://schemas.microsoft.com/ws/2008/06/identity/claims/role'
        ];
    }

    if (this.role === 'Admin') this.getAdminHomeData();
  }

  getAdminHomeData = () => {
    this.adminService.getAllNewsRequests().subscribe(
      (res: any) => {
        this.message = res.message;
        console.log(res.message);
        if ((status = 'Success')) {
          this.newsRequests = res;
        } else if (res.status == 'Error') {
          this.message = res.message;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  };

  approveNews = (id: string) => {
    console.log(id);
    this.adminService.approveNewsRequest(id).subscribe(
      (res: any) => {
        var statusActiv = res.isActive;

        if (statusActiv == true || status == 'Success') {
          this.toastrService.success(
            'Employee news request accepted successfully',
            'success'
          );
          window.location.reload();
        } else {
          this.message = res.message;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  };

  giveAlert = (alert: HTMLElement) => {
    alert.style.display = 'inherit';
  };

  removeAlert = (alert: HTMLElement) => {
    alert.style.display = 'none';
  };

  ngOnInit(): void {}
}
