import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsRequestComponent } from './news-request.component';

describe('NewsRequestComponent', () => {
  let component: NewsRequestComponent;
  let fixture: ComponentFixture<NewsRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewsRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
