import { Component, OnInit, Input } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';
import { AdminServicesService } from 'src/app/services/admin-service.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-reg-request',
  templateUrl: './reg-request.component.html',
  styleUrls: ['./reg-request.component.scss'],
})
export class RegRequestComponent implements OnInit {
  helper = new JwtHelperService();
  userName: any;
  email: any;
  role: any;
  token: any;
  regRequests: any;
  message: any;
  constructor(
    private adminService: AdminServicesService,
    private router: Router,
    private toastrService: ToastrService
  ) {
    this.token = localStorage.getItem('token');
    if (this.token != null) {
      const decodedToken = this.helper.decodeToken(this.token);
      this.userName =
        decodedToken[
          'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'
        ];
      console.log(this.userName);
      this.email = decodedToken.email;
      this.role =
        decodedToken[
          'http://schemas.microsoft.com/ws/2008/06/identity/claims/role'
        ];
    }

    if (this.role === 'Admin')
     this.getAdminHomeData();
    else 
      this.toastrService.success('Access Denied', 'success');
  }

  ngOnInit(): void {}

  getAdminHomeData = () => {
    this.adminService.getAllRegistrationRequests().subscribe(
      (res: any) => {
        if ((status = 'Success')) {
          this.regRequests = res;
        } else if (res.status == 'Error') this.message = res.message;
      },
      (err: any) => {
        console.log(err);
      }
    );
  };

  approveRequest = (userName: string) => {
    this.adminService.approveRegistrationRequest(userName).subscribe(
      (res: any) => {
        var status = res.isActive;
        this.message = res.message;

        if (status == true) {
          this.toastrService.success(
            'Employee Account Has Been  Activated successfully',
            'success'
          );
          window.location.reload();
        } else {
          this.toastrService.success(
            'Employee Account Has Been Deactivated successfully',
            'success'
          );
          window.location.reload();
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  };
}
