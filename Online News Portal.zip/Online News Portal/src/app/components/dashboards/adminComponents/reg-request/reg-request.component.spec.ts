import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegRequestComponent } from './reg-request.component';

describe('RegRequestComponent', () => {
  let component: RegRequestComponent;
  let fixture: ComponentFixture<RegRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
