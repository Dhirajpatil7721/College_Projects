import { Component, OnInit, Input } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';
import { AdminServicesService } from 'src/app/services/admin-service.service';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.scss'],
})
export class AddCategoryComponent implements OnInit {
  helper = new JwtHelperService();
   userName?: string | null
  email?: string | null
  role?: string | null
  token: any
  getCategory: any
  addCategory: any
  message: any
  category: any
 

  constructor(
    private formBuilder: FormBuilder,
    private adminService: AdminServicesService,
    private router: Router,
    private toastrService: ToastrService
  ) {
    this.token = localStorage.getItem('token');
    if (this.token != null) {
      const decodedToken = this.helper.decodeToken(this.token);
      this.userName = sessionStorage.getItem('userName');

      this.role = sessionStorage.getItem('role');
    }

    if (this.role === 'Admin') this.getAdminHomeData();
    else this.toastrService.success('Access Denied', 'success');
  }

  getAdminHomeData = () => {
    this.adminService.getAllCategory().subscribe(
      (res: any) => {
        if ((status = 'Success')) {
          this.getCategory = res;
        } else this.message = res.message;
      },
      (err: any) => {
        console.log(err);
      }
    );
  };

  removeCategory(id: string) {
    this.adminService.removeCategory(id).subscribe((res: any) => {
      console.log(res);

      if ((status = 'Success')) {
        this.toastrService.success('Category removed successfully', 'success');
        window.location.reload();
      } else {
        this.toastrService.success('Error while removing category ', 'success');
      }
    });
  }

  ngOnInit(): void {
    this.addCategory = this.formBuilder.group({
      category: ['', Validators.required],
    });
  }

  addCategoryByAdmin() {
    const categoryModel = {
      name: this.addCategory.value['category'],
    };

    this.adminService.addCategory(categoryModel).subscribe((res: any) => {
      console.log(res);

      if (res.status == 'Success') {
        this.toastrService.success('Category added successfully', 'success');
        window.location.reload();
      } else if (res.status == 'Error--500') {
        this.toastrService.error('Category Already Exist!!! ', 'error');
      }
    });
  }
}
