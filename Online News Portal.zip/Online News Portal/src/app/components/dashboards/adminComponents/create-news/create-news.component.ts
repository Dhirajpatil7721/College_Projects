import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminServicesService } from 'src/app/services/admin-service.service';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';

@Component({
  selector: 'app-create-news',
  templateUrl: './create-news.component.html',
  styleUrls: ['./create-news.component.scss']
})
export class CreateNewsComponent implements OnInit {

newsForm:FormGroup;
submitted=false
categoryList:any;
ddlCategory = "";
role:any;
  constructor(private fb:FormBuilder,private router:Router,private adminService :AdminServicesService,private _toastr:ToastrService, private employeeService:EmployeeServiceService) 
  {
    this.newsForm = this.fb.group({
      title:['',Validators.required] ,
      category:['',Validators.required] ,
      description:['',Validators.required],
      location:['',Validators.required],
      imgLink: [''],
      publishedDate:['',Validators.required]
    })
    this.categoryList=[];
   }

   get f() { return this.newsForm.controls; }

  ngOnInit(): void {
    this.role = sessionStorage.getItem('role')
    if(this.role ==  'Admin'){
      this.adminService.getAllCategory().subscribe((response:any)=>{
        this.categoryList =  response;
    },
    (err : any)=>{
      console.log(err);
    })
  }
    else{
      this.employeeService.getAllCategory().subscribe((response: any)=>{
        this.categoryList =  response;
      },
      (err : any)=>{
        console.log(err);
      })
    }
  
  }

  onSubmit(){
    var link=this.newsForm.value.imgLink.slice(12);
    this.newsForm.value.imageLink="assets/images/"+link;
    const body={
      "title":this.newsForm.value['title'],
      "category":this.newsForm.value['category'],
      "description": this.newsForm.value['description'],
      "location": this.newsForm.value['location'],
      "publishedDate":this.newsForm.value['publishedDate'],
     "imgLink": this.newsForm.value.imageLink="assets/images/"+link,
     "ModifiedDate":this.newsForm.value.publishedDate,
     "userId":sessionStorage['userId']
 
    }
   
  
    if(this.role== "Admin"){
      this.adminService.CreateNews(body).subscribe((response: any) => {
        
        if(response.status=="Success"){
          this._toastr.success("News added successfully")
        }
       
      },(error: { error: { title: string | undefined; }; }) => {
        this._toastr.error(error.error.title)
        console.log(error)
      });

    }
    else{

      this.employeeService.CreateNews(body).subscribe((response: any) => {
       
        if(response.status=="Success")
          this._toastr.success("News added successfully")
        
        
      },error => {
        this._toastr.error(error.error.title)
        console.log(error)
      });
    }
   
    this.newsForm.reset();
  }


}
