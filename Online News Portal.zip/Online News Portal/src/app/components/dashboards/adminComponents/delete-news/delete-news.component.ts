import { Component, OnInit } from '@angular/core';
import { AdminServicesService } from 'src/app/services/admin-service.service'
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-delete-news',
  templateUrl: './delete-news.component.html',
  styleUrls: ['./delete-news.component.scss'],
})
export class DeleteNewsComponent implements OnInit {
  newsData: any;
  message: any;
  constructor(
    private adminService: AdminServicesService,
    private toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this.adminService.getData().subscribe(
      (data: any) => {
        console.log(data);
        if ((status = 'Success')) {
          this.newsData = data;
        } else if (data.status == 'Error') this.message = data.message;
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  deleteNewsRequest = (id: number) => {
    this.adminService.deleteNewsRequest(id).subscribe(
      (res: any) => {
        if (status == 'Success') {
          this.toastrService.success('News Deleted successfully', 'success');
          window.location.reload();
        } else {
          this.toastrService.error('Error while deleting the news ', 'error');
          window.location.reload();
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  };
}
