import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
//import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ConfirmedValidator } from 'src/app/confirmed.validator';
import { LoginAndRegistrationService } from 'src/app/services/login-and-registration.service';
import { IRegister } from 'src/app/interface/iregister';
import { ToastrService } from 'ngx-toastr';
  

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.scss']
})
export class RegistrationFormComponent implements OnInit {


  
  
  
  
  pwdPattern =
  '(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-zd$@$!%*?&].{8,}';
emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';

message: any;
registerForm: any;

constructor(
  private formBuilder: FormBuilder,
  private regService: LoginAndRegistrationService,
  private router: Router,
  private _toastr: ToastrService
) {}

ngOnInit(): void {
  this.registerForm = this.formBuilder.group(
    {
      firstName: [
        '',
        [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]+')],
      ],
      lastName: [
        '',
        [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]+')],
      ],
      userName: ['', Validators.required],
      email: [
        '',
        [Validators.required, Validators.pattern(this.emailPattern)],
      ],

      password: [
        '',
        [Validators.required, Validators.pattern(this.pwdPattern)],
      ],

      confirm_password: ['', [Validators.required]],
    },
    {
      validator: ConfirmedValidator('password', 'confirm_password'),
    }
  );
}
onFormSubmit() {
  if (this.registerForm.invalid) {
    return;
  }
  const regObj: IRegister = {
    firstName: this.registerForm.value['firstName'],
    lastName: this.registerForm.value['lastName'],
    userName: this.registerForm.value['userName'],
    email: this.registerForm.value['email'],

    password: this.registerForm.value['password'],
  };

  this.regService.register(regObj).subscribe((res: any) => {
    if (res.status == 'Success') {
      this.router.navigateByUrl('regnotification');
    } else {
      this._toastr.error('User Name Already Present', 'Error');
    }
  });

  this.registerForm.reset();
}

get f() {
  return this.registerForm.controls;
}


}
