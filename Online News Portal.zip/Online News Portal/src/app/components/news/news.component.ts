import { Component, OnInit } from '@angular/core';
import { NewsService } from 'src/app/services/news.service'
import { AdminServicesService } from 'src/app/services/admin-service.service';
import { ToastrService } from 'ngx-toastr';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {

  search = "";
  newsData: any = []
  newsDataWeb: any = []
  message: any
  employeeDetals?: any[];
  role: any
  user: any
  categoryList: any;
  starPerformer:any;


  constructor(private news: NewsService, private adminService: AdminServicesService, private _toastr: ToastrService, private employeeService: EmployeeServiceService) {
    this.user = this.role = sessionStorage.getItem('role');
    if (this.user == "Admin") {
      this.adminService.getData().subscribe((data: any) => {
        if (status = "Success") {
          this.newsData = data;
        } else if (data.status == 'Error')
          this.message = data.message
      },
        (err: any) => {
          console.log(err);

        })

    } else {
      this.employeeService.getData().subscribe((data: any) => {
        if (status = "Success") {
          this.newsData = data;
        } else if (data.status == 'Error')
          this.message = data.message
      },
        (err: any) => {
          console.log(err);

        })
    }

    this.news.getUserName().subscribe((data: any) => {
      if (status = "Success") {
        this.employeeDetals = data;
      } else if (data.status == 'Error')
        this.message = data.message
    },
      (err: any) => {
        console.log(err);
      })



  }
  ngOnInit(): void {


    this.employeeService.starPerformer().subscribe((response:any)=> {
      console.log(response);
      this.starPerformer = response;
      this.starPerformer[0];
      
    },
      (err: any) => {
        console.log(err);
      })




    this.role = sessionStorage.getItem('role')
    if (this.role == 'Admin') {
      this.adminService.getAllCategory().subscribe((response: any) => {
        this.categoryList = response;
      },
        (err: any) => {
          console.log(err);
        })
    }
    else {
      this.employeeService.getAllCategory().subscribe(response => {
        this.categoryList = response;
      },
        (err: any) => {
          console.log(err);
        })
    }

  }


}
