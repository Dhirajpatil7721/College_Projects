import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter',
})
export class FilterPipe implements PipeTransform {
  transform(value: any[], search: any): any[] {
    if (!value) return [];
    if (!search) return value;
    else
      return value.filter((item) => {
        console.log('Inside Pipe');
        return item.category.toLowerCase().includes(search.toLowerCase());
      });
  }
}

