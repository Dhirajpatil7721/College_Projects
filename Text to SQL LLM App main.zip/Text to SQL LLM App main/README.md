## Gemini Query: Unleashing Data Insights with Conversational SQL

gemini-pro model used for retrieving data from prompting.
The database has been created using SQL lite 3.  

'Leveraged Gemini AI to build an innovative data retrieval app utilizing natural language queries. 
Designed a user-friendly interface for effortless data exploration and optimized query performance to deliver rapid insights.'

