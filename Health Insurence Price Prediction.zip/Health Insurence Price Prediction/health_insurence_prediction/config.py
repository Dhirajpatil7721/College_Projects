import os

MODEL_FILE_PATH = 'project_app/Linear_model.pkl'

JSON_FILE_PATH = 'project_app/project_data.json'

PORT_NUMBER = 8080

